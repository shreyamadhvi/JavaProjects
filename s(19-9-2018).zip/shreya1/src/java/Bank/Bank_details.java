/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bank;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Viki
 */
public class Bank_details extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Bank_details</title>");
            out.println("</head>");
            out.println("<body>");
            // out.println("<h1>Servlet Bank_details at " + request.getContextPath() + "</h1>");
            try {
                ServletConfig sc = getServletConfig();
                out.println(sc.getInitParameter("drivername"));
                out.println(sc.getInitParameter("tableName"));

                String account_holder = "";
                String email = "";
                int contactnumber = 0;
                int account_Number = 0;
                String city = "";
                String branches = "";
                String accounttype = "";
                String openaccount_with = "";
                try {
                    try {
                        account_holder = request.getParameter("account_holder");
                        Cookie user = new Cookie("acthold", account_holder);
                        response.addCookie(user);

                        Cookie ck[] = request.getCookies();
                        for (int i = 0; i < ck.length; i++) {
                            out.print("<br>" + ck[i].getName() + " " + ck[i].getValue());//printing name and value of cookie  
                        }
                        if (account_holder == null || account_holder.equals("")) {
                            throw new NullPointerException("Account holder is blank");
                        } else {
                            account_holder = request.getParameter("account_holder");
                        }
                    } catch (NullPointerException e) {
                        out.print("<h1> " + e.getMessage() + "</h1>");
                    }
                    email = request.getParameter("email");
                    if (request.getParameter("contactnumber") instanceof String) {
                        throw new NumberFormatException("Please Enter digits");
                    } else if (request.getParameter("account_Number") instanceof String) {
                        throw new NumberFormatException("Please Enter digits");
                    }
                    contactnumber = Integer.parseInt(request.getParameter("contactnumber"));
                    account_Number = Integer.parseInt(request.getParameter("account_Number"));

                    city = request.getParameter("city");
                    branches = request.getParameter("Branches");
                    accounttype = request.getParameter("accounttype");
                    openaccount_with = request.getParameter("openaccount_with");
                    if (email == null || city == null || branches == null || accounttype == null || openaccount_with == null) {
                        throw new NullPointerException("Please fill the data");
                    }

                    out.println("<h1>welcome</h1>");
                    out.print("<h1> " + " Account_holder:    " + account_holder + "</h1>");
                    out.print("<h1>" + "email:  " + email + " </h1>");
                    out.print("<h1> " + "contactnumber:  " + contactnumber + " </h1>");
                    out.print("<h1> " + "account_Number:  " + account_Number + " </h1>");
                    out.print("<h1> " + "city:  " + city + " </h1>");
                    out.print("<h1> " + "Branches:  " + branches + " </h1>");
                    out.print("<h1> " + "accounttype:   " + accounttype + " </h1>");
                    out.print("<h1>" + "openaccount_with:  " + openaccount_with + " </h1>");

                } catch (NumberFormatException | NullPointerException e) {
                    out.print("<h1> " + e.getMessage() + "</h1>");
                }
                try {
                    if (account_holder.equals("shreya madhvi")) {
                        RequestDispatcher r = request.getRequestDispatcher("welcome.html");

                        out.print("<h1> " + " Fix deposite information : " + "</h1>");
                        r.include(request, response);
                    } else {
                        RequestDispatcher r = request.getRequestDispatcher("error.html");
                        r.include(request, response);
                    }
                } catch (ServletException | IOException | NullPointerException servletException) {
                    System.out.println(servletException);
                }

                // String[] size = request.getParameterValues("size");
                // RequestDispatcher rd = request.getRequestDispatcher("welcome.html");
                //out.print("<div class= 'container'><div class='card text-white bg-info mb-3' style='max-width: 20rem;'>");
                //out.print("<div class='card-header'>" + product + "</div>");
                //out.print("<div class='card-body'><h4 class='card-title'>"+ productdescription + "</h4>");
                //out.print("<p class='card-text'>"+"productprice:" + " " + productprice + "</p>");
                //out.print("<p class='card-text'>"+"accounttype:" + " " + producttype + "</p>");
                //out.print("<p class='card-text'>"+"city:" + " " + city + "</p>");
//                out.print("<h1>" + "productprice:" + " " + productprice + " </h1>");
//                out.print("<h1>" + "producttype:" + " " + producttype + " </h1>");
//                out.print("<h1>" + "city:" + " " + city + " </h1>");
                //out.print("<h1>size:</h1>");
                //for (String string : size) {
                //  out.print("<p class='card-text'>"+ string + "</p>");
                //}
                //out.print("</div></div></div>");
            } catch (Exception e) {
                out.println("error : " + e);
            }

            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
