/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bank;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Viki
 */
public class Bank_details extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Bank_details</title>");            
            out.println("</head>");
            out.println("<body>");
           // out.println("<h1>Servlet Bank_details at " + request.getContextPath() + "</h1>");
            try {
                  out.println("<h1>welcom</h1>");

                String account_holder  = request.getParameter("account_holder");
                String email = request.getParameter("email");
                int contactnumber = Integer.parseInt(request.getParameter("contactnumber"));
                int account_Number = Integer.parseInt(request.getParameter("account_Number"));
                String city = request.getParameter("city");
                String Branches = request.getParameter("Branches");
                String  accounttype = request.getParameter("accounttype");
                String  openaccount_with = request.getParameter("openaccount_with");


                out.print("<h1> "+ " Account_holder:    " + account_holder + "</h1>");
                out.print("<h1>"+"email:  " +email + " !</h1>");
                out.print("<h1> " +"contactnumber:  "+ contactnumber + " </h1>");
                out.print("<h1> "+"account_Number:  " + account_Number + " </h1>");
                out.print("<h1> " +"city:  "+ city + " </h1>");
                out.print("<h1> "+"Branches:  " + Branches + " </h1>");
                out.print("<h1> "+"accounttype:   " + accounttype + " </h1>");
                out.print("<h1>" +"openaccount_with:  "+ openaccount_with + " </h1>");
                 if(account_holder .equals("shreya madhvi")){
                
                 
                RequestDispatcher r = request.getRequestDispatcher("welcome.html");
                out.print("<h1> "+ " Fix deposite information : "+"</h1>");
                r.include(request, response);
                 }else{
                     out.println("<h1>not valid  </h1>");
                 }






               // String[] size = request.getParameterValues("size");
               // RequestDispatcher rd = request.getRequestDispatcher("welcome.html");
                //out.print("<div class= 'container'><div class='card text-white bg-info mb-3' style='max-width: 20rem;'>");
                //out.print("<div class='card-header'>" + product + "</div>");
                //out.print("<div class='card-body'><h4 class='card-title'>"+ productdescription + "</h4>");
                //out.print("<p class='card-text'>"+"productprice:" + " " + productprice + "</p>");
                //out.print("<p class='card-text'>"+"accounttype:" + " " + producttype + "</p>");
                //out.print("<p class='card-text'>"+"city:" + " " + city + "</p>");
            
//                out.print("<h1>" + "productprice:" + " " + productprice + " </h1>");
//                out.print("<h1>" + "producttype:" + " " + producttype + " </h1>");
//                out.print("<h1>" + "city:" + " " + city + " </h1>");
                //out.print("<h1>size:</h1>");

                //for (String string : size) {
                  //  out.print("<p class='card-text'>"+ string + "</p>");
                //}
                //out.print("</div></div></div>");
            } catch (Exception e) {
                out.println("error : " + e);
            }
            
            
            
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
