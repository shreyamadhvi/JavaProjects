/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Shreya;

import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 *
 * @author iiht
 */
public class schoolMain {

    static SessionFactory sessionFactory = null;
    static Session session = null;
    static Transaction transaction = null;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

//        try {
//            connection();
//            transaction = session.beginTransaction();
//            School sc = new School(3, "sumit", 12, "A", "C");
//            session.update(sc);
//            System.out.println("success");
//            transaction.commit();
//        } catch (HibernateException hibernateException) {
//            System.out.println("error:" + hibernateException);
//        } finally {
//            session.close();
//            sessionFactory.close();
//
//        }
//        try {
//            connection();
//            // from cluase//
//            //String hql="FROM School";
//            String hql = "SELECT s.divison,COUNT(s.studentId)AS Stcout FROM School AS s GROUP BY s.divison";
//            Query query = session.createQuery(hql);
//           
//
//            List<Object> result = (List<Object>) query.list();
//            Iterator itr = result.iterator();
//            while (itr.hasNext()) {
//                Object[] obj = (Object[]) itr.next();
//                //now you have one array of Object for each row
//                String client = String.valueOf(obj[0]); // don't know the type of column CLIENT assuming String 
//                Integer service = Integer.parseInt(String.valueOf(obj[1])); //SERVICE assumed as int
//                //same way for all obj[2], obj[3], obj[4]
//                
//                System.out.println("Div :" + client + "\t Count:" + service);
//            }
//
//           
//        } catch (Exception e) {
//            System.out.println("Error: " + e);
//            System.exit(0);
//        } finally {
//            session.close();
//            sessionFactory.close();
//            System.exit(0);
//
//        }
//        try {
//            connection();
//            // from cluase//
//            //String hql="FROM School";
//            String hql = "FROM School AS s WHERE  s.divison = :div";
//            Query query = session.createQuery(hql);
//            query.setParameter("div", "A");
//
//            List<School> result = query.list();
//            //now you have one array of Object for each row
//            for (School school : result) {
//                System.out.println(school.toString());
//            }
//
//            //same way for all obj[2], obj[3], obj[4]
//        } catch (Exception e) {
//            System.out.println("Error: " + e.getCause());
//            System.exit(0);
//        } finally {
//            session.close();
//            sessionFactory.close();
//            System.exit(0);
//
//        }
        try {
            connection();
            // from cluase//
            //String hql="FROM School";
            String hql = "FROM School";
            Query query = session.createQuery(hql);
            int size = query.list().size();
            
            for (int i = 0; i < size; i++) {
                System.out.println("-------------------------------------------");
                query.setFirstResult(i);
                query.setMaxResults(1);
                List<School> result = query.list();
                //now you have one array of Object for each row
                for (School school : result) {
                    System.out.println(school.toString());
                }
                System.out.println("-------------------------------------------");
            }
            

            //same way for all obj[2], obj[3], obj[4]
        } catch (Exception e) {
            System.out.println("Error: " + e.getCause());
            System.exit(0);
        } finally {
            session.close();
            sessionFactory.close();
            System.exit(0);

        }

    }

    static void connection() {
        sessionFactory = NewHibernateUtil.getSessionFactory();
        session = sessionFactory.openSession();
    }
}
