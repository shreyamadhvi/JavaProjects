/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Shreya;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 *
 * @author iiht
 */
public class schoolMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        SessionFactory sessionFactory = null;
        Session session = null;
        Transaction transaction = null;
        try {
            sessionFactory = NewHibernateUtil.getSessionFactory();
            session = sessionFactory.openSession();
            transaction = session.beginTransaction();
            School sc = new School(3,"sumit",12,"A","C");
            session.update(sc);
            System.out.println("success");
            transaction.commit();
        } catch (HibernateException hibernateException) {
            System.out.println("error:"+hibernateException);
        } finally {
            session.close();
            sessionFactory.close();
            System.exit(0);
        }

    }
}
