/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scientificC;

import java.io.Serializable;

/**
 *
 * @author iiht
 */
public class scC implements Serializable {

    public static final long sid = 1L;
    private int a, b;

    @Override
    public String toString() {
        return "scC{" + "a=" + a + ", b=" + b + '}';
    }

    public int getA() {
        return a;
    }

    public int getB() {
        return b;
    }

    public void setA(int a) {
        this.a = a;
    }

    public void setB(int b) {
        this.b = b;
    }
}
