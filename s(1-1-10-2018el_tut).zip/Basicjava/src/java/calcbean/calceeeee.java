/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calcbean;

import chapter2.MethodTypes;
import java.io.Serializable;

/**
 *
 * @author iiht
 */
public class calceeeee implements Serializable{
   // public int cube(int n){return n*n*n;}
      private static final long sid = 1L;
      private int a,b,c;

     public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }

    public int getC() {
        return MethodTypes.mul(a, b);
    }
//
//    public void setC(int c) {
//        this.c = c;
//    }
    
              
    
}
